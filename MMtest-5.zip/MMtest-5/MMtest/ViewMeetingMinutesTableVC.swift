//
//  ViewMeetingMinutesTableVC.swift
//  Testmeetmin
//
//  Created by Podduturu, Apoorva Reddy on 10/26/19.
//  Copyright © 2019 Varun Chillara. All rights reserved.
//

import UIKit
import AWSAppSync

class ViewMeetingMinutesTableVC: UITableViewController {

    var agendadataArray:[String]=[]
    var attendeesdataArray:[String?]=[]
    var detailsdataArray:[String]=[]
    var deadlinedataArray:[String]=[]
    var emaildataArray:[String]=[]
    
    
    var selectedrow : Any = []
    var index : Int = 0

    var appSyncClient: AWSAppSyncClient?
    var discard: Cancellable?
    
    override func viewDidLoad() {
         
        super.viewDidLoad()
        print("view mm..")
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appSyncClient = appDelegate.appSyncClient
        self.runQuery()
        self.tableView.reloadData()
       
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    
   
    func runQuery(){
        print("run Query started")
   //   appSyncClient?.fetch(query: ListMMsQuery())
        appSyncClient?.fetch(query: ListMMsQuery(),cachePolicy: .fetchIgnoringCacheData) {(result, error) in
            if error != nil {
                print(error?.localizedDescription ?? "")
                return
            }
 
            print("Query complete.")
            result?.data?.listMMs?.items!.forEach
                {
                    self.agendadataArray.append($0!.agenda)
                 //   self.attendeesdataArray.append($0!.attendees)
                    self.detailsdataArray.append($0!.details!)
                    
                //    print(self.detailsdataArray)
                    self.deadlinedataArray.append($0!.deadline!)
                //    print(self.deadlinedataArray)
                       // self.emaildataArray.append($0!.email)
                    
                    //print(self.dataArray)
                   self.tableView.reloadData()
                    //print(self.dataArray[0])
                  //  print(($0?.agenda)! + " " + ($0?.details)!)
                    
            }
        }
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return agendadataArray.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath)

     //  print(self.detailsdataArray[indexPath.row])
         //print(self.deadlinedataArray[indexPath.row])
        
        
        let a = agendadataArray[indexPath.row]
        cell.textLabel?.text = a
        //tableView.reloadData()
        

        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        index = tableView.indexPathForSelectedRow!.row
       //print(index)
            selectedrow = self.agendadataArray[indexPath.row]
            performSegue(withIdentifier: "ViewDetailVC", sender: self)
         tableView.reloadData()
        }
        
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "ViewDetailVC"{
                if let detailVC = segue.destination as? ViewDetailVC{
                 
                    detailVC.Passedlabel = selectedrow
                    detailVC.PasseddetailsdataArray = detailsdataArray
                    detailVC.PasseddeadlinedataArray = deadlinedataArray
                    detailVC.PassedIndex = index
                 
                }
            }
        }

   
}
