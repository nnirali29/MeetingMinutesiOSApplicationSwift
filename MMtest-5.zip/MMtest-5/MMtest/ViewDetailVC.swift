//
//  ViewDetailVC.swift
//  MMtest
//
//  Created by Patel, Nirali Arvindbhai on 12/11/19.
//  Copyright © 2019 Varun Chillara. All rights reserved.
//

import UIKit

class ViewDetailVC: UIViewController {

    var Passedlabel : Any = []
      
    
    var PasseddetailsdataArray:[String]=[]
       var PasseddeadlinedataArray:[String]=[]
    
    
    var PassedIndex : Int = 0
    @IBOutlet weak var txtViewAgenda: UITextView!
    
    
    @IBOutlet weak var txtViewDetail: UITextView!
    
    @IBOutlet weak var txtFieldDeadline: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(PassedIndex)
        
        switch PassedIndex{
                 case 0 :
                      print("0 selected .....")
                      txtViewDetail.text = PasseddetailsdataArray[0]
                      txtFieldDeadline.text = PasseddeadlinedataArray[0]
                      
               case 1 :
                 print("1 selected .....")
                 txtViewDetail.text = PasseddetailsdataArray[1]
                 txtFieldDeadline.text = PasseddeadlinedataArray[1]
            case 2 :
            print("2 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[2]
            txtFieldDeadline.text = PasseddeadlinedataArray[2]
            case 3 :
            print("3 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[3]
            txtFieldDeadline.text = PasseddeadlinedataArray[3]
            case 4 :
            print("4 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[4]
            txtFieldDeadline.text = PasseddeadlinedataArray[4]
            case 5 :
            print("5 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[5]
            txtFieldDeadline.text = PasseddeadlinedataArray[5]
            case 6 :
            print("6 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[6]
            txtFieldDeadline.text = PasseddeadlinedataArray[6]
            case 7 :
            print("7 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[7]
            txtFieldDeadline.text = PasseddeadlinedataArray[7]
            case 8 :
            print("8 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[8]
            txtFieldDeadline.text = PasseddeadlinedataArray[8]
            case 9 :
            print("9 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[9]
            txtFieldDeadline.text = PasseddeadlinedataArray[9]
            case 10 :
            print("10 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[10]
            txtFieldDeadline.text = PasseddeadlinedataArray[10]
            case 11 :
            print("11 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[11]
            txtFieldDeadline.text = PasseddeadlinedataArray[11]
            case 12 :
            print("12 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[12]
            txtFieldDeadline.text = PasseddeadlinedataArray[12]
            case 13 :
            print("13 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[13]
            txtFieldDeadline.text = PasseddeadlinedataArray[13]
            case 14 :
            print("14 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[14]
            txtFieldDeadline.text = PasseddeadlinedataArray[14]
            case 15 :
            print("15 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[15]
            txtFieldDeadline.text = PasseddeadlinedataArray[15]
            case 16 :
            print("16 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[16]
            txtFieldDeadline.text = PasseddeadlinedataArray[16]
            case 17 :
            print("17 selected .....")
            txtViewDetail.text = PasseddetailsdataArray[17]
            txtFieldDeadline.text = PasseddeadlinedataArray[17]
                      
                         
                    default:
                        print("error")
                    }
      //  print(Passedlabel)
       // print(PasseddetailsdataArray)
       // print(PasseddeadlinedataArray)
        
        txtViewAgenda.text = Passedlabel as! String
        // Do any additional setup after loading the view.
    }
    

    

}
