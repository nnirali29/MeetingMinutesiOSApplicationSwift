//
//  CreateMeetingMinutesViewController.swift
//  MMtest
//
//  Created by Podduturu, Apoorva Reddy on 11/23/19.
//  Copyright © 2019 Varun Chillara. All rights reserved.
//

import UIKit
import AWSAppSync

class CreateMeetingMinutesViewController: UIViewController {

    var appSyncClient: AWSAppSyncClient?
    
    @IBOutlet weak var agendaTextView: UITextView!
    @IBOutlet weak var attendeesTextField: UITextField!
    @IBOutlet weak var detailsTextView: UITextView!
    @IBOutlet weak var deadlineTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appSyncClient = appDelegate.appSyncClient
        // Do any additional setup after loading the view.
    }
    
    func runMutation(){
        let emailString=emailTextField.text
        let emailArray=emailString?.components(separatedBy: ",")
        
        let mutationInput = CreateMMInput(agenda: agendaTextView.text, attendees: [attendeesTextField.text!], details: detailsTextView.text, deadline: deadlineTextField.text, email: [emailTextField.text!])
        appSyncClient?.perform(mutation: CreateMmMutation(input: mutationInput)) { (result, error) in
            if let error = error as? AWSAppSyncClientError {
                print("Error occurred: \(error.localizedDescription )")
            }
            if let resultError = result?.errors {
                print("Error saving the item on server: \(resultError)")
                return
            }
            print("Mutation complete.", result.debugDescription)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func saveAndSubmitBtnActn(_ sender: Any) {
        self.runMutation()
        
    }
    
}
